<?php
    $this->load->view('front/layout/header');
    $this->load->view($content);
    $this->load->view('front/layout/footer');