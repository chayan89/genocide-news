<div class="header-bottom sticky-header">
    <div class="container">
        <div class="row">
            <div class="menu_wrap">
                <div id="cssmenu">
                    <ul>
                    <li><a href="index.html">New In</a></li>
                    <li ><a href="index.html">Bedroom </a></li>
                    <li><a href="about-us.html">Home</a></li>
                    <li>
                        <a href="booking.html">Clothing</a>
                        <ul>
                            <li>
                                <h3>new in clothing</h3>
                                <a href="#">Vintage & 2nd hand</a>
                                <a href="#">Vintage & 2nd hand</a>
                                <a href="#">Vintage & 2nd hand</a>
                                <a href="#">Vintage & 2nd hand</a>
                            </li>
                            <li>
                                <h3>new in clothing</h3>
                                <a href="#">Vintage & 2nd hand</a>
                                <a href="#">Vintage & 2nd hand</a>
                                <a href="#">Vintage & 2nd hand</a>
                                <a href="#">Vintage & 2nd hand</a>
                            </li>
                            <li>
                                <h3>new in clothing</h3>
                                <a href="#">Vintage & 2nd hand</a>
                                <a href="#">Vintage & 2nd hand</a>
                                <a href="#">Vintage & 2nd hand</a>
                                <a href="#">Vintage & 2nd hand</a>
                            </li>
                            <li>
                                <h3>new in clothing</h3>
                                <img src="<?= base_url('public/front/img/product1.png')?>" alt="banner">
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="kids-partys.html">Candles & Fragrance</a>
                        <ul>
                            <li>
                                <h3>new in clothing</h3>
                                <a href="#">Vintage & 2nd hand</a>
                                <a href="#">Vintage & 2nd hand</a>
                                <a href="#">Vintage & 2nd hand</a>
                                <a href="#">Vintage & 2nd hand</a>
                            </li>
                            <li>
                                <h3>new in clothing</h3>
                                <a href="#">Vintage & 2nd hand</a>
                                <a href="#">Vintage & 2nd hand</a>
                                <a href="#">Vintage & 2nd hand</a>
                                <a href="#">Vintage & 2nd hand</a>
                            </li>
                            <li>
                                <h3>new in clothing</h3>
                                <a href="#">Vintage & 2nd hand</a>
                                <a href="#">Vintage & 2nd hand</a>
                                <a href="#">Vintage & 2nd hand</a>
                                <a href="#">Vintage & 2nd hand</a>
                            </li>
                            <li>
                                <h3>new in clothing</h3>
                                <a href="#">Vintage & 2nd hand</a>
                                <a href="#">Vintage & 2nd hand</a>
                                <a href="#">Vintage & 2nd hand</a>
                                <a href="#">Vintage & 2nd hand</a>
                            </li>
                        </ul>
                    </li>
                    <li><a href="tournament.html">Baby & Children</a></li>
                    <li><a href="photo-video-gallery.html">Gifts</a></li>
                    <li><a href="contact-us.html">INSPIRE</a></li>
                    <li><a href="contact-us.html">Sale</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>